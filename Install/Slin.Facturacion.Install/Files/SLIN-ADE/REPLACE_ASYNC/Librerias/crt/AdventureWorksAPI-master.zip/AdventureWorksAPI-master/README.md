# AdventureWorksAPI
Web API application sample developed with asp.net core

http://www.codeproject.com/Articles/1112848/Creating-Web-API-in-ASP-NET-Core
